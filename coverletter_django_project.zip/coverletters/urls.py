from django.urls import path, include
from .views import coverletter_detail_view

urlpatterns = [
    path('<int:id>/', coverletter_detail_view, name='coverletter-detail'),
]
