from django.db import models

class Coverletter(models.Model):
    body = models.TextField()
