from django.shortcuts import render



def coverletter_detail_view(request):
    pass
